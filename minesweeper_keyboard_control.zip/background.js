// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log("Minesweeper Keyboard Control Extension Installed");
});
