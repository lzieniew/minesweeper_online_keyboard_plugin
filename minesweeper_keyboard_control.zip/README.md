# minesweeper_online_keyboard_plugin
A simple firefox plugin for playing minesweeper.online with keyboard, instead of mouse
